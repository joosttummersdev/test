/*
  # Update Admin Password

  1. Changes
    - Updates password for admin user (joost@yoobar.nl) to 'admin1234'
*/

-- Update admin user password
SELECT auth.update_user(
  id := (SELECT id FROM auth.users WHERE email = 'joost@yoobar.nl'),
  password := 'admin1234'
);