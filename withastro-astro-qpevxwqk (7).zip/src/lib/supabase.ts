// Re-export everything from supabaseClient
export * from './supabaseClient';